import { query } from '../../db/connection';
import { calculateSecurityScore } from '../scoring/scoring-engine';
import { generateRecommendations } from '../recommendations/recommendation-engine';
import { getAssessmentData } from '../assessment/assessment-data-adapter';
import { saveSecurityScore } from '../persistence/score-repository';
import type { SecurityScoreResult } from '../types';

export async function processAssessmentScore(assessmentId: string): Promise<SecurityScoreResult | null> {
  try {
    const assessment = await getAssessmentData(assessmentId);
    if (!assessment) {
      console.warn(`Assessment ${assessmentId} not found for scoring`);
      return null;
    }

    if (!['completed', 'partial'].includes(assessment.status)) {
      console.warn(`Assessment ${assessmentId} status is ${assessment.status}, skipping scoring`);
      return null;
    }

    const scoreResult = calculateSecurityScore(assessment);
    const recommendations = generateRecommendations(assessment, scoreResult);
    const finalResult = { ...scoreResult, recommendations };

    await saveSecurityScore(finalResult);

    return finalResult;
  } catch (error) {
    console.error(`Security scoring failed for assessment ${assessmentId}:`, error);
    return null;
  }
}

export async function getScoreForAssessment(assessmentId: string): Promise<SecurityScoreResult | null> {
  try {
    const rows = await query(
      'SELECT * FROM security_scores WHERE assessment_id = ? LIMIT 1',
      [assessmentId]
    );

    if (rows.length === 0) return null;
    const row = rows[0] as any;
    return {
      assessmentId: row.assessment_id,
      tenantId: row.tenant_id,
      calculatedAt: row.calculated_at,
      overallScore: row.overall_score,
      securityRating: row.security_rating,
      summary: JSON.parse(row.summary || '{}'),
      severityBreakdown: JSON.parse(row.severity_breakdown || '{}'),
      categoryScores: JSON.parse(row.category_scores || '[]'),
      failedControls: JSON.parse(row.failed_controls || '[]'),
      recommendations: JSON.parse(row.recommendations || '[]'),
      assessmentType: row.assessment_type || 'quick',
    };
  } catch (error) {
    console.error(`Failed to load score for assessment ${assessmentId}:`, error);
    return null;
  }
}
