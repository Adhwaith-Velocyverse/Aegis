import { query } from '../../db/connection';
import type { SecurityScoreResult } from '../types';

export async function attachScoreToReport(assessmentId: string, score: SecurityScoreResult): Promise<void> {
  const existing = await query(
    'SELECT id FROM assessment_metadata WHERE assessment_id = ? AND key = ?',
    [assessmentId, 'security_score']
  );

  const scoreJson = JSON.stringify(score);

  if (existing.length > 0) {
    await query(
      'UPDATE assessment_metadata SET value = ? WHERE id = ?',
      [scoreJson, (existing[0] as any).id]
    );
  } else {
    await query(
      'INSERT INTO assessment_metadata (id, assessment_id, key, value) VALUES (?, ?, ?, ?)',
      [require('uuid').v4(), assessmentId, 'security_score', scoreJson]
    );
  }

  const categoriesJson = JSON.stringify(score.categoryScores);
  const existingCategories = await query(
    'SELECT id FROM assessment_metadata WHERE assessment_id = ? AND key = ?',
    [assessmentId, 'category_scores']
  );

  if (existingCategories.length > 0) {
    await query(
      'UPDATE assessment_metadata SET value = ? WHERE id = ?',
      [categoriesJson, (existingCategories[0] as any).id]
    );
  } else {
    await query(
      'INSERT INTO assessment_metadata (id, assessment_id, key, value) VALUES (?, ?, ?, ?)',
      [require('uuid').v4(), assessmentId, 'category_scores', categoriesJson]
    );
  }

  const recommendationsJson = JSON.stringify(score.recommendations);
  const existingRecs = await query(
    'SELECT id FROM assessment_metadata WHERE assessment_id = ? AND key = ?',
    [assessmentId, 'recommendations']
  );

  if (existingRecs.length > 0) {
    await query(
      'UPDATE assessment_metadata SET value = ? WHERE id = ?',
      [recommendationsJson, (existingRecs[0] as any).id]
    );
  } else {
    await query(
      'INSERT INTO assessment_metadata (id, assessment_id, key, value) VALUES (?, ?, ?, ?)',
      [require('uuid').v4(), assessmentId, 'recommendations', recommendationsJson]
    );
  }
}
