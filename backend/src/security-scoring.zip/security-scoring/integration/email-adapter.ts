import { sendEmail, createNotification } from '../../services/notifications';
import type { SecurityScoreResult } from '../types';

export async function sendScoreEmail(userId: string, assessmentId: string, score: SecurityScoreResult): Promise<void> {
  const topRecommendations = score.recommendations.slice(0, 5);
  const recommendationsHtml = topRecommendations.length > 0
    ? `<ul>${topRecommendations.map(r => `<li>${r.title}: ${r.description}</li>`).join('')}</ul>`
    : '<p>No critical recommendations at this time.</p>';

  const html = `
    <h2>Security Assessment Completed</h2>
    <p><strong>Overall Security Score:</strong> ${score.overallScore}/100</p>
    <p><strong>Security Rating:</strong> ${score.securityRating}</p>
    <p><strong>Assessment Type:</strong> ${score.assessmentType}</p>
    <h3>Controls Summary</h3>
    <ul>
      <li>Passed: ${score.summary.passedControls}</li>
      <li>Partial: ${score.summary.partialControls}</li>
      <li>Failed: ${score.summary.failedControls}</li>
      <li>Not Assessed: ${score.summary.notAssessedControls}</li>
    </ul>
    <h3>Severity Breakdown</h3>
    <ul>
      <li>Critical Issues: ${score.severityBreakdown.critical}</li>
      <li>High Issues: ${score.severityBreakdown.high}</li>
      <li>Medium Issues: ${score.severityBreakdown.medium}</li>
      <li>Low Issues: ${score.severityBreakdown.low}</li>
    </ul>
    <h3>Top Recommendations</h3>
    ${recommendationsHtml}
    <p>The detailed report is available in the application.</p>
  `;

  await createNotification(
    userId,
    'assessment_score_detail',
    'Security Score & Recommendations',
    `Your security assessment scored ${score.overallScore}/100 (${score.securityRating}).`,
    { assessmentId, overallScore: score.overallScore, securityRating: score.securityRating }
  );

  const users = await require('../../db/connection').query('SELECT email, full_name FROM users WHERE id = ?', [userId]);
  if (users.length > 0) {
    const user = users[0] as any;
    await sendEmail(
      user.email,
      'Your Aegis Security Assessment Score & Recommendations',
      `<p>Hi ${user.full_name},</p>${html}`
    );
  }
}
