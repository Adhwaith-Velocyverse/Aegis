import { describe, it, expect } from 'vitest';
import { calculateSecurityScore } from '../scoring/scoring-engine';
import { generateRecommendations } from '../recommendations/recommendation-engine';
import type { NormalizedAssessment } from '../types';

function makeAssessment(overrides: Partial<NormalizedAssessment> = {}): NormalizedAssessment {
  return {
    assessmentId: 'test-1',
    tenantId: 'tenant-1',
    organizationId: 'org-1',
    assessmentType: 'quick',
    collectedAt: new Date().toISOString(),
    status: 'completed',
    controls: [],
    ...overrides,
  };
}

describe('Security Scoring Engine', () => {
  it('returns 100 for all passing controls', () => {
    const assessment = makeAssessment({
      controls: [
        { controlId: '1', name: 'MFA', moduleName: 'Entra ID', status: 'PASS', severity: 'HIGH', weight: 2 },
        { controlId: '2', name: 'Legacy Auth', moduleName: 'Entra ID', status: 'PASS', severity: 'MEDIUM', weight: 1 },
      ],
    });
    const result = calculateSecurityScore(assessment);
    expect(result.overallScore).toBe(100);
    expect(result.securityRating).toBe('Excellent');
    expect(result.summary.passedControls).toBe(2);
    expect(result.summary.failedControls).toBe(0);
  });

  it('returns 0 for all failing controls', () => {
    const assessment = makeAssessment({
      controls: [
        { controlId: '1', name: 'MFA', moduleName: 'Entra ID', status: 'FAIL', severity: 'HIGH', weight: 2 },
        { controlId: '2', name: 'Legacy Auth', moduleName: 'Entra ID', status: 'FAIL', severity: 'MEDIUM', weight: 1 },
      ],
    });
    const result = calculateSecurityScore(assessment);
    expect(result.overallScore).toBe(0);
    expect(result.summary.failedControls).toBe(2);
  });

  it('calculates weighted score for mixed results', () => {
    const assessment = makeAssessment({
      controls: [
        { controlId: '1', name: 'MFA', moduleName: 'Entra ID', status: 'PASS', severity: 'CRITICAL', weight: 2 },
        { controlId: '2', name: 'Legacy Auth', moduleName: 'Entra ID', status: 'FAIL', severity: 'HIGH', weight: 1 },
      ],
    });
    const result = calculateSecurityScore(assessment);
    expect(result.overallScore).toBeGreaterThan(0);
    expect(result.overallScore).toBeLessThan(100);
  });

  it('handles empty controls', () => {
    const assessment = makeAssessment({ controls: [] });
    const result = calculateSecurityScore(assessment);
    expect(result.overallScore).toBe(0);
    expect(result.summary.totalControls).toBe(0);
  });

  it('handles PARTIAL status', () => {
    const assessment = makeAssessment({
      controls: [
        { controlId: '1', name: 'MFA', moduleName: 'Entra ID', status: 'PARTIAL', severity: 'HIGH', weight: 2 },
      ],
    });
    const result = calculateSecurityScore(assessment);
    expect(result.summary.partialControls).toBe(1);
    expect(result.overallScore).toBeGreaterThan(0);
    expect(result.overallScore).toBeLessThan(100);
  });

  it('calculates category scores', () => {
    const assessment = makeAssessment({
      controls: [
        { controlId: '1', name: 'MFA', moduleName: 'Entra ID', category: 'Identity', status: 'PASS', severity: 'HIGH', weight: 2 },
        { controlId: '2', name: 'Anti-phish', moduleName: 'Email', category: 'Email Security', status: 'FAIL', severity: 'CRITICAL', weight: 1 },
      ],
    });
    const result = calculateSecurityScore(assessment);
    expect(result.categoryScores.length).toBeGreaterThanOrEqual(2);
  });

  it('generates severity breakdown', () => {
    const assessment = makeAssessment({
      controls: [
        { controlId: '1', name: 'MFA', moduleName: 'Entra ID', status: 'FAIL', severity: 'CRITICAL', weight: 1 },
        { controlId: '2', name: 'Legacy Auth', moduleName: 'Entra ID', status: 'FAIL', severity: 'HIGH', weight: 1 },
      ],
    });
    const result = calculateSecurityScore(assessment);
    expect(result.severityBreakdown.critical).toBe(1);
    expect(result.severityBreakdown.high).toBe(1);
  });
});

describe('Recommendation Engine', () => {
  it('generates recommendation for known failed control', () => {
    const assessment = makeAssessment({
      controls: [
        { controlId: '1', name: 'Anti-phishing policy exists and enabled', moduleName: 'Email', status: 'FAIL', severity: 'CRITICAL', weight: 2 },
      ],
    });
    const scoreResult = calculateSecurityScore(assessment);
    const recommendations = generateRecommendations(assessment, scoreResult);
    expect(recommendations.length).toBeGreaterThan(0);
    expect(recommendations[0].title).toContain('anti-phishing');
  });

  it('returns empty recommendations when no controls fail', () => {
    const assessment = makeAssessment({
      controls: [
        { controlId: '1', name: 'MFA', moduleName: 'Entra ID', status: 'PASS', severity: 'HIGH', weight: 2 },
      ],
    });
    const scoreResult = calculateSecurityScore(assessment);
    const recommendations = generateRecommendations(assessment, scoreResult);
    expect(recommendations.length).toBe(0);
  });

  it('deduplicates recommendations for same failure type', () => {
    const assessment = makeAssessment({
      controls: [
        { controlId: '1', name: 'Anti-phishing policy exists and enabled', moduleName: 'Email', status: 'FAIL', severity: 'CRITICAL', weight: 2 },
        { controlId: '2', name: 'All users are covered by at least one enabled MDO Anti-Phishing policy', moduleName: 'Email', status: 'FAIL', severity: 'HIGH', weight: 2 },
      ],
    });
    const scoreResult = calculateSecurityScore(assessment);
    const recommendations = generateRecommendations(assessment, scoreResult);
    const titles = recommendations.map(r => r.title);
    expect(titles.filter(t => t.includes('anti-phishing')).length).toBeGreaterThanOrEqual(1);
  });
});
