import type { NormalizedAssessment, Recommendation, SecurityScoreResult } from '../types';
import { getRecommendationForControl } from '../config/scoring-config';
import { SCORING_CONFIG } from '../config/scoring-config';

export function generateRecommendations(
  assessment: NormalizedAssessment,
  scoreResult: SecurityScoreResult
): Recommendation[] {
  const recommendations: Recommendation[] = [];
  const seen = new Set<string>();
  const grouped = new Map<string, { recommendation: ReturnType<typeof getRecommendationForControl>; controls: string[] }>();

  for (const control of assessment.controls) {
    if (control.status.toUpperCase() !== 'FAIL') continue;

    const rec = getRecommendationForControl(control.name);
    if (!rec) continue;

    if (!grouped.has(rec.title)) {
      grouped.set(rec.title, { recommendation: rec, controls: [] });
    }
    grouped.get(rec.title)!.controls.push(control.controlId);
  }

  let priority = 1;
  for (const [title, group] of grouped) {
    if (!group.recommendation) continue;
    const severity = deriveSeverity(group.controls, assessment);
    const recommendation: Recommendation = {
      id: generateRecommendationId(group.controls[0]),
      controlId: group.controls[0],
      title: group.recommendation.title,
      description: group.recommendation.description,
      severity,
      priority,
      remediation: group.recommendation.remediation,
      reason: `Failed controls: ${group.controls.join(', ')}`,
      affectedControls: group.controls,
    };
    recommendations.push(recommendation);
    priority++;
  }

  recommendations.sort((a, b) => {
    const order = { CRITICAL: 0, HIGH: 1, MEDIUM: 2, LOW: 3 };
    const cmp = (order[a.severity as keyof typeof order] || 2) - (order[b.severity as keyof typeof order] || 2);
    if (cmp !== 0) return cmp;
    return a.priority - b.priority;
  });

  return recommendations.slice(0, SCORING_CONFIG.maxRecommendations);
}

function deriveSeverity(controlIds: string[], assessment: NormalizedAssessment): 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW' {
  let maxSeverity = 'LOW';
  const order = { CRITICAL: 4, HIGH: 3, MEDIUM: 2, LOW: 1 };

  for (const c of assessment.controls) {
    if (controlIds.includes(c.controlId)) {
      const sev = mapSeverity(c.severity);
      if ((order[sev as keyof typeof order] || 0) > (order[maxSeverity as keyof typeof order] || 0)) {
        maxSeverity = sev;
      }
    }
  }

  return maxSeverity as 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
}

function mapSeverity(severity: string): string {
  const upper = severity.toUpperCase();
  if (['CRITICAL', 'HIGH', 'MEDIUM', 'LOW'].includes(upper)) return upper;
  return 'MEDIUM';
}

function generateRecommendationId(seed: string): string {
  let hash = 0;
  for (let i = 0; i < seed.length; i++) {
    hash = ((hash << 5) - hash + seed.charCodeAt(i)) | 0;
  }
  return `REC-${Math.abs(hash).toString(16).toUpperCase().padStart(8, '0')}`;
}
