import { query } from '../../db/connection';
import type { SecurityScoreResult } from '../types';

export async function saveSecurityScore(score: SecurityScoreResult): Promise<void> {
  const scoreId = require('uuid').v4();

  await query(
    `INSERT INTO security_scores (id, assessment_id, tenant_id, overall_score, security_rating, summary, severity_breakdown, category_scores, failed_controls, recommendations, calculated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      scoreId,
      score.assessmentId,
      score.tenantId,
      score.overallScore,
      score.securityRating,
      JSON.stringify(score.summary),
      JSON.stringify(score.severityBreakdown),
      JSON.stringify(score.categoryScores),
      JSON.stringify(score.failedControls),
      JSON.stringify(score.recommendations),
      score.calculatedAt,
    ]
  );
}

export async function getLatestScore(tenantId: string): Promise<SecurityScoreResult | null> {
  const rows = await query(
    `SELECT * FROM security_scores WHERE tenant_id = ? ORDER BY calculated_at DESC LIMIT 1`,
    [tenantId]
  );

  if (rows.length === 0) return null;
  return parseScoreRow(rows[0] as any);
}

export async function getScoreByAssessmentId(assessmentId: string): Promise<SecurityScoreResult | null> {
  const rows = await query(
    `SELECT * FROM security_scores WHERE assessment_id = ? LIMIT 1`,
    [assessmentId]
  );

  if (rows.length === 0) return null;
  return parseScoreRow(rows[0] as any);
}

function parseScoreRow(row: any): SecurityScoreResult {
  return {
    assessmentId: row.assessment_id,
    tenantId: row.tenant_id,
    calculatedAt: row.calculated_at,
    overallScore: row.overall_score,
    securityRating: row.security_rating,
    summary: JSON.parse(row.summary || '{}'),
    severityBreakdown: JSON.parse(row.severity_breakdown || '{}'),
    categoryScores: JSON.parse(row.category_scores || '[]'),
    failedControls: JSON.parse(row.failed_controls || '[]'),
    recommendations: JSON.parse(row.recommendations || '[]'),
    assessmentType: row.assessment_type || 'quick',
  };
}
